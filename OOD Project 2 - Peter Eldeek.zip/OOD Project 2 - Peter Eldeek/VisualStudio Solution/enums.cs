﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public enum SIZE
    {
        big,
        medium,
        small
    }

    public enum BURGERTYPE
    {
        beef,
        chicken
    }

    public enum DRINKTYPE
    {
        coke,
        pepsi,
        miranda,
        sprite,
        icetea
    }
}
