﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public class Fries
    {
        public SIZE size { get; set; }
        public bool Salted { get; set; }
        public bool Peeled { get; set; }
        public void Modify(bool isSalted, bool isPeeled)
        {
            this.Salted = isSalted;
            this.Peeled = isPeeled;
        }

    }
}
