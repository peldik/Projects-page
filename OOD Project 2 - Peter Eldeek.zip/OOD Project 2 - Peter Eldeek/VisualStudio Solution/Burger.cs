﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public class Burger
    {
        public SIZE size { get; set; }
        public BURGERTYPE type { get; set; }
        public void Modify(BURGERTYPE burgertype)
        {
            this.type = burgertype;
        }
    }


}
