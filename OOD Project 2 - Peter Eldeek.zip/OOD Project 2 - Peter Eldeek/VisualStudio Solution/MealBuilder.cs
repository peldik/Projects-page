﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public abstract class MealBuilder
    {
        public Meal meal = new Meal();
        public abstract void BuildBurger();
        public abstract void BuildFries();
        public abstract void BuildDrink();
    }

    public class BigMealBuilder : MealBuilder
    {
        public override void BuildBurger()
        {
            meal.burger.size = SIZE.big;
        }
        public override void BuildFries()
        {
            meal.fries.size = SIZE.big;
        }
        public override void BuildDrink()
        {
            meal.drink.size = SIZE.big;
        }
    }
    public class MediumMealBuilder : MealBuilder
    {
        public override void BuildBurger()
        {
            meal.burger.size = SIZE.medium;
        }
        public override void BuildFries()
        {
            meal.fries.size = SIZE.medium;
        }
        public override void BuildDrink()
        {
            meal.drink.size = SIZE.medium;
        }
    }
    public class SmallMealBuilder : MealBuilder
    {
        public override void BuildBurger()
        {
            meal.burger.size = SIZE.small;
        }
        public override void BuildFries()
        {
            meal.fries.size = SIZE.small;
        }
        public override void BuildDrink()
        {
            meal.drink.size = SIZE.small;
        }
    }

}
