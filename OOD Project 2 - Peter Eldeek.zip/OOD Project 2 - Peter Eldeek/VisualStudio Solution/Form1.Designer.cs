﻿namespace Project_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMakeOrder = new System.Windows.Forms.Button();
            this.groupBoxMealSize = new System.Windows.Forms.GroupBox();
            this.rBtnSmallBurger = new System.Windows.Forms.RadioButton();
            this.rbtnMediumBurger = new System.Windows.Forms.RadioButton();
            this.rbtnBigBurger = new System.Windows.Forms.RadioButton();
            this.groupBoxBurgerType = new System.Windows.Forms.GroupBox();
            this.rbtnChicken = new System.Windows.Forms.RadioButton();
            this.rbtnBeef = new System.Windows.Forms.RadioButton();
            this.groupBoxFriesOptions = new System.Windows.Forms.GroupBox();
            this.checkBoxPeeled = new System.Windows.Forms.CheckBox();
            this.checkBoxSalted = new System.Windows.Forms.CheckBox();
            this.groupBoxDrinkType = new System.Windows.Forms.GroupBox();
            this.rbtnIceTea = new System.Windows.Forms.RadioButton();
            this.rbtnPepsi = new System.Windows.Forms.RadioButton();
            this.rbtnSprite = new System.Windows.Forms.RadioButton();
            this.rbtnCoke = new System.Windows.Forms.RadioButton();
            this.rbtnMiranda = new System.Windows.Forms.RadioButton();
            this.groupBoxAddress = new System.Windows.Forms.GroupBox();
            this.btnSaveAddress = new System.Windows.Forms.Button();
            this.textBoxResidentName = new System.Windows.Forms.TextBox();
            this.labelResidentName = new System.Windows.Forms.Label();
            this.numericFloorNumber = new System.Windows.Forms.NumericUpDown();
            this.textBoxBuilding = new System.Windows.Forms.TextBox();
            this.textBoxStreet = new System.Windows.Forms.TextBox();
            this.labelFloorNumber = new System.Windows.Forms.Label();
            this.labelBuilding = new System.Windows.Forms.Label();
            this.labelStreet = new System.Windows.Forms.Label();
            this.textBoxCity = new System.Windows.Forms.TextBox();
            this.labelCity = new System.Windows.Forms.Label();
            this.listBoxAddresses = new System.Windows.Forms.ListBox();
            this.labelSavedAddresses = new System.Windows.Forms.Label();
            this.groupBoxMealSize.SuspendLayout();
            this.groupBoxBurgerType.SuspendLayout();
            this.groupBoxFriesOptions.SuspendLayout();
            this.groupBoxDrinkType.SuspendLayout();
            this.groupBoxAddress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericFloorNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMakeOrder
            // 
            this.btnMakeOrder.Location = new System.Drawing.Point(44, 316);
            this.btnMakeOrder.Name = "btnMakeOrder";
            this.btnMakeOrder.Size = new System.Drawing.Size(338, 95);
            this.btnMakeOrder.TabIndex = 0;
            this.btnMakeOrder.Text = "Make Order";
            this.btnMakeOrder.UseVisualStyleBackColor = true;
            this.btnMakeOrder.Click += new System.EventHandler(this.btnMakeOrder_Click);
            // 
            // groupBoxMealSize
            // 
            this.groupBoxMealSize.Controls.Add(this.rBtnSmallBurger);
            this.groupBoxMealSize.Controls.Add(this.rbtnMediumBurger);
            this.groupBoxMealSize.Controls.Add(this.rbtnBigBurger);
            this.groupBoxMealSize.Location = new System.Drawing.Point(44, 31);
            this.groupBoxMealSize.Name = "groupBoxMealSize";
            this.groupBoxMealSize.Size = new System.Drawing.Size(338, 113);
            this.groupBoxMealSize.TabIndex = 1;
            this.groupBoxMealSize.TabStop = false;
            this.groupBoxMealSize.Text = "Meal Size";
            // 
            // rBtnSmallBurger
            // 
            this.rBtnSmallBurger.AutoSize = true;
            this.rBtnSmallBurger.Location = new System.Drawing.Point(145, 68);
            this.rBtnSmallBurger.Name = "rBtnSmallBurger";
            this.rBtnSmallBurger.Size = new System.Drawing.Size(50, 17);
            this.rBtnSmallBurger.TabIndex = 2;
            this.rBtnSmallBurger.TabStop = true;
            this.rBtnSmallBurger.Text = "Small";
            this.rBtnSmallBurger.UseVisualStyleBackColor = true;
            // 
            // rbtnMediumBurger
            // 
            this.rbtnMediumBurger.AutoSize = true;
            this.rbtnMediumBurger.Location = new System.Drawing.Point(145, 45);
            this.rbtnMediumBurger.Name = "rbtnMediumBurger";
            this.rbtnMediumBurger.Size = new System.Drawing.Size(62, 17);
            this.rbtnMediumBurger.TabIndex = 1;
            this.rbtnMediumBurger.TabStop = true;
            this.rbtnMediumBurger.Text = "Medium";
            this.rbtnMediumBurger.UseVisualStyleBackColor = true;
            // 
            // rbtnBigBurger
            // 
            this.rbtnBigBurger.AutoSize = true;
            this.rbtnBigBurger.Checked = true;
            this.rbtnBigBurger.Location = new System.Drawing.Point(145, 22);
            this.rbtnBigBurger.Name = "rbtnBigBurger";
            this.rbtnBigBurger.Size = new System.Drawing.Size(40, 17);
            this.rbtnBigBurger.TabIndex = 0;
            this.rbtnBigBurger.TabStop = true;
            this.rbtnBigBurger.Text = "Big";
            this.rbtnBigBurger.UseVisualStyleBackColor = true;
            // 
            // groupBoxBurgerType
            // 
            this.groupBoxBurgerType.Controls.Add(this.rbtnChicken);
            this.groupBoxBurgerType.Controls.Add(this.rbtnBeef);
            this.groupBoxBurgerType.Location = new System.Drawing.Point(44, 163);
            this.groupBoxBurgerType.Name = "groupBoxBurgerType";
            this.groupBoxBurgerType.Size = new System.Drawing.Size(101, 126);
            this.groupBoxBurgerType.TabIndex = 2;
            this.groupBoxBurgerType.TabStop = false;
            this.groupBoxBurgerType.Text = "Burger Type";
            // 
            // rbtnChicken
            // 
            this.rbtnChicken.AutoSize = true;
            this.rbtnChicken.Location = new System.Drawing.Point(7, 54);
            this.rbtnChicken.Name = "rbtnChicken";
            this.rbtnChicken.Size = new System.Drawing.Size(64, 17);
            this.rbtnChicken.TabIndex = 1;
            this.rbtnChicken.TabStop = true;
            this.rbtnChicken.Text = "Chicken";
            this.rbtnChicken.UseVisualStyleBackColor = true;
            // 
            // rbtnBeef
            // 
            this.rbtnBeef.AutoSize = true;
            this.rbtnBeef.Checked = true;
            this.rbtnBeef.Location = new System.Drawing.Point(7, 30);
            this.rbtnBeef.Name = "rbtnBeef";
            this.rbtnBeef.Size = new System.Drawing.Size(47, 17);
            this.rbtnBeef.TabIndex = 0;
            this.rbtnBeef.TabStop = true;
            this.rbtnBeef.Text = "Beef";
            this.rbtnBeef.UseVisualStyleBackColor = true;
            // 
            // groupBoxFriesOptions
            // 
            this.groupBoxFriesOptions.Controls.Add(this.checkBoxPeeled);
            this.groupBoxFriesOptions.Controls.Add(this.checkBoxSalted);
            this.groupBoxFriesOptions.Location = new System.Drawing.Point(160, 163);
            this.groupBoxFriesOptions.Name = "groupBoxFriesOptions";
            this.groupBoxFriesOptions.Size = new System.Drawing.Size(106, 126);
            this.groupBoxFriesOptions.TabIndex = 4;
            this.groupBoxFriesOptions.TabStop = false;
            this.groupBoxFriesOptions.Text = "Fries Options";
            // 
            // checkBoxPeeled
            // 
            this.checkBoxPeeled.AutoSize = true;
            this.checkBoxPeeled.Checked = true;
            this.checkBoxPeeled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxPeeled.Location = new System.Drawing.Point(7, 55);
            this.checkBoxPeeled.Name = "checkBoxPeeled";
            this.checkBoxPeeled.Size = new System.Drawing.Size(59, 17);
            this.checkBoxPeeled.TabIndex = 1;
            this.checkBoxPeeled.Text = "Peeled";
            this.checkBoxPeeled.UseVisualStyleBackColor = true;
            // 
            // checkBoxSalted
            // 
            this.checkBoxSalted.AutoSize = true;
            this.checkBoxSalted.Checked = true;
            this.checkBoxSalted.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxSalted.Location = new System.Drawing.Point(7, 30);
            this.checkBoxSalted.Name = "checkBoxSalted";
            this.checkBoxSalted.Size = new System.Drawing.Size(56, 17);
            this.checkBoxSalted.TabIndex = 0;
            this.checkBoxSalted.Text = "Salted";
            this.checkBoxSalted.UseVisualStyleBackColor = true;
            // 
            // groupBoxDrinkType
            // 
            this.groupBoxDrinkType.Controls.Add(this.rbtnIceTea);
            this.groupBoxDrinkType.Controls.Add(this.rbtnPepsi);
            this.groupBoxDrinkType.Controls.Add(this.rbtnSprite);
            this.groupBoxDrinkType.Controls.Add(this.rbtnCoke);
            this.groupBoxDrinkType.Controls.Add(this.rbtnMiranda);
            this.groupBoxDrinkType.Location = new System.Drawing.Point(285, 163);
            this.groupBoxDrinkType.Name = "groupBoxDrinkType";
            this.groupBoxDrinkType.Size = new System.Drawing.Size(97, 129);
            this.groupBoxDrinkType.TabIndex = 6;
            this.groupBoxDrinkType.TabStop = false;
            this.groupBoxDrinkType.Text = "DrinkType";
            // 
            // rbtnIceTea
            // 
            this.rbtnIceTea.AutoSize = true;
            this.rbtnIceTea.Location = new System.Drawing.Point(9, 109);
            this.rbtnIceTea.Name = "rbtnIceTea";
            this.rbtnIceTea.Size = new System.Drawing.Size(59, 17);
            this.rbtnIceTea.TabIndex = 9;
            this.rbtnIceTea.Text = "IceTea";
            this.rbtnIceTea.UseVisualStyleBackColor = true;
            // 
            // rbtnPepsi
            // 
            this.rbtnPepsi.AutoSize = true;
            this.rbtnPepsi.Location = new System.Drawing.Point(9, 40);
            this.rbtnPepsi.Name = "rbtnPepsi";
            this.rbtnPepsi.Size = new System.Drawing.Size(51, 17);
            this.rbtnPepsi.TabIndex = 1;
            this.rbtnPepsi.Text = "Pepsi";
            this.rbtnPepsi.UseVisualStyleBackColor = true;
            // 
            // rbtnSprite
            // 
            this.rbtnSprite.AutoSize = true;
            this.rbtnSprite.Location = new System.Drawing.Point(9, 86);
            this.rbtnSprite.Name = "rbtnSprite";
            this.rbtnSprite.Size = new System.Drawing.Size(52, 17);
            this.rbtnSprite.TabIndex = 8;
            this.rbtnSprite.Text = "Sprite";
            this.rbtnSprite.UseVisualStyleBackColor = true;
            // 
            // rbtnCoke
            // 
            this.rbtnCoke.AutoSize = true;
            this.rbtnCoke.Checked = true;
            this.rbtnCoke.Location = new System.Drawing.Point(9, 19);
            this.rbtnCoke.Name = "rbtnCoke";
            this.rbtnCoke.Size = new System.Drawing.Size(50, 17);
            this.rbtnCoke.TabIndex = 0;
            this.rbtnCoke.TabStop = true;
            this.rbtnCoke.Text = "Coke";
            this.rbtnCoke.UseVisualStyleBackColor = true;
            // 
            // rbtnMiranda
            // 
            this.rbtnMiranda.AutoSize = true;
            this.rbtnMiranda.Location = new System.Drawing.Point(9, 63);
            this.rbtnMiranda.Name = "rbtnMiranda";
            this.rbtnMiranda.Size = new System.Drawing.Size(63, 17);
            this.rbtnMiranda.TabIndex = 7;
            this.rbtnMiranda.Text = "Miranda";
            this.rbtnMiranda.UseVisualStyleBackColor = true;
            // 
            // groupBoxAddress
            // 
            this.groupBoxAddress.Controls.Add(this.btnSaveAddress);
            this.groupBoxAddress.Controls.Add(this.textBoxResidentName);
            this.groupBoxAddress.Controls.Add(this.labelResidentName);
            this.groupBoxAddress.Controls.Add(this.numericFloorNumber);
            this.groupBoxAddress.Controls.Add(this.textBoxBuilding);
            this.groupBoxAddress.Controls.Add(this.textBoxStreet);
            this.groupBoxAddress.Controls.Add(this.labelFloorNumber);
            this.groupBoxAddress.Controls.Add(this.labelBuilding);
            this.groupBoxAddress.Controls.Add(this.labelStreet);
            this.groupBoxAddress.Controls.Add(this.textBoxCity);
            this.groupBoxAddress.Controls.Add(this.labelCity);
            this.groupBoxAddress.Location = new System.Drawing.Point(416, 31);
            this.groupBoxAddress.Name = "groupBoxAddress";
            this.groupBoxAddress.Size = new System.Drawing.Size(277, 258);
            this.groupBoxAddress.TabIndex = 7;
            this.groupBoxAddress.TabStop = false;
            this.groupBoxAddress.Text = "Address";
            // 
            // btnSaveAddress
            // 
            this.btnSaveAddress.Location = new System.Drawing.Point(19, 207);
            this.btnSaveAddress.Name = "btnSaveAddress";
            this.btnSaveAddress.Size = new System.Drawing.Size(240, 45);
            this.btnSaveAddress.TabIndex = 10;
            this.btnSaveAddress.Text = "Save Address";
            this.btnSaveAddress.UseVisualStyleBackColor = true;
            this.btnSaveAddress.Click += new System.EventHandler(this.btnSaveAddress_Click);
            // 
            // textBoxResidentName
            // 
            this.textBoxResidentName.Location = new System.Drawing.Point(137, 136);
            this.textBoxResidentName.Name = "textBoxResidentName";
            this.textBoxResidentName.Size = new System.Drawing.Size(122, 20);
            this.textBoxResidentName.TabIndex = 9;
            // 
            // labelResidentName
            // 
            this.labelResidentName.AutoSize = true;
            this.labelResidentName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelResidentName.Location = new System.Drawing.Point(16, 137);
            this.labelResidentName.Name = "labelResidentName";
            this.labelResidentName.Size = new System.Drawing.Size(115, 16);
            this.labelResidentName.TabIndex = 8;
            this.labelResidentName.Text = "Resident Name";
            // 
            // numericFloorNumber
            // 
            this.numericFloorNumber.Location = new System.Drawing.Point(137, 169);
            this.numericFloorNumber.Name = "numericFloorNumber";
            this.numericFloorNumber.Size = new System.Drawing.Size(122, 20);
            this.numericFloorNumber.TabIndex = 7;
            this.numericFloorNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBuilding
            // 
            this.textBoxBuilding.Location = new System.Drawing.Point(137, 99);
            this.textBoxBuilding.Name = "textBoxBuilding";
            this.textBoxBuilding.Size = new System.Drawing.Size(122, 20);
            this.textBoxBuilding.TabIndex = 6;
            // 
            // textBoxStreet
            // 
            this.textBoxStreet.Location = new System.Drawing.Point(137, 65);
            this.textBoxStreet.Name = "textBoxStreet";
            this.textBoxStreet.Size = new System.Drawing.Size(122, 20);
            this.textBoxStreet.TabIndex = 5;
            // 
            // labelFloorNumber
            // 
            this.labelFloorNumber.AutoSize = true;
            this.labelFloorNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFloorNumber.Location = new System.Drawing.Point(16, 172);
            this.labelFloorNumber.Name = "labelFloorNumber";
            this.labelFloorNumber.Size = new System.Drawing.Size(102, 16);
            this.labelFloorNumber.TabIndex = 4;
            this.labelFloorNumber.Text = "Floor Number";
            // 
            // labelBuilding
            // 
            this.labelBuilding.AutoSize = true;
            this.labelBuilding.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBuilding.Location = new System.Drawing.Point(16, 99);
            this.labelBuilding.Name = "labelBuilding";
            this.labelBuilding.Size = new System.Drawing.Size(64, 16);
            this.labelBuilding.TabIndex = 3;
            this.labelBuilding.Text = "Building";
            // 
            // labelStreet
            // 
            this.labelStreet.AutoSize = true;
            this.labelStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStreet.Location = new System.Drawing.Point(16, 65);
            this.labelStreet.Name = "labelStreet";
            this.labelStreet.Size = new System.Drawing.Size(49, 16);
            this.labelStreet.TabIndex = 2;
            this.labelStreet.Text = "Street";
            // 
            // textBoxCity
            // 
            this.textBoxCity.Location = new System.Drawing.Point(137, 28);
            this.textBoxCity.Name = "textBoxCity";
            this.textBoxCity.Size = new System.Drawing.Size(122, 20);
            this.textBoxCity.TabIndex = 1;
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCity.Location = new System.Drawing.Point(16, 28);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(34, 16);
            this.labelCity.TabIndex = 0;
            this.labelCity.Text = "City";
            // 
            // listBoxAddresses
            // 
            this.listBoxAddresses.FormattingEnabled = true;
            this.listBoxAddresses.Location = new System.Drawing.Point(416, 342);
            this.listBoxAddresses.Name = "listBoxAddresses";
            this.listBoxAddresses.Size = new System.Drawing.Size(358, 69);
            this.listBoxAddresses.TabIndex = 8;
            // 
            // labelSavedAddresses
            // 
            this.labelSavedAddresses.AutoSize = true;
            this.labelSavedAddresses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSavedAddresses.Location = new System.Drawing.Point(413, 306);
            this.labelSavedAddresses.Name = "labelSavedAddresses";
            this.labelSavedAddresses.Size = new System.Drawing.Size(132, 16);
            this.labelSavedAddresses.TabIndex = 9;
            this.labelSavedAddresses.Text = "Saved Addresses";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelSavedAddresses);
            this.Controls.Add(this.listBoxAddresses);
            this.Controls.Add(this.groupBoxAddress);
            this.Controls.Add(this.groupBoxDrinkType);
            this.Controls.Add(this.groupBoxFriesOptions);
            this.Controls.Add(this.groupBoxBurgerType);
            this.Controls.Add(this.groupBoxMealSize);
            this.Controls.Add(this.btnMakeOrder);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBoxMealSize.ResumeLayout(false);
            this.groupBoxMealSize.PerformLayout();
            this.groupBoxBurgerType.ResumeLayout(false);
            this.groupBoxBurgerType.PerformLayout();
            this.groupBoxFriesOptions.ResumeLayout(false);
            this.groupBoxFriesOptions.PerformLayout();
            this.groupBoxDrinkType.ResumeLayout(false);
            this.groupBoxDrinkType.PerformLayout();
            this.groupBoxAddress.ResumeLayout(false);
            this.groupBoxAddress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericFloorNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMakeOrder;
        private System.Windows.Forms.GroupBox groupBoxMealSize;
        private System.Windows.Forms.RadioButton rBtnSmallBurger;
        private System.Windows.Forms.RadioButton rbtnMediumBurger;
        private System.Windows.Forms.RadioButton rbtnBigBurger;
        private System.Windows.Forms.GroupBox groupBoxBurgerType;
        private System.Windows.Forms.RadioButton rbtnChicken;
        private System.Windows.Forms.RadioButton rbtnBeef;
        private System.Windows.Forms.GroupBox groupBoxFriesOptions;
        private System.Windows.Forms.CheckBox checkBoxPeeled;
        private System.Windows.Forms.CheckBox checkBoxSalted;
        private System.Windows.Forms.GroupBox groupBoxDrinkType;
        private System.Windows.Forms.RadioButton rbtnIceTea;
        private System.Windows.Forms.RadioButton rbtnPepsi;
        private System.Windows.Forms.RadioButton rbtnSprite;
        private System.Windows.Forms.RadioButton rbtnCoke;
        private System.Windows.Forms.RadioButton rbtnMiranda;
        private System.Windows.Forms.GroupBox groupBoxAddress;
        private System.Windows.Forms.TextBox textBoxResidentName;
        private System.Windows.Forms.Label labelResidentName;
        private System.Windows.Forms.NumericUpDown numericFloorNumber;
        private System.Windows.Forms.TextBox textBoxBuilding;
        private System.Windows.Forms.TextBox textBoxStreet;
        private System.Windows.Forms.Label labelFloorNumber;
        private System.Windows.Forms.Label labelBuilding;
        private System.Windows.Forms.Label labelStreet;
        private System.Windows.Forms.TextBox textBoxCity;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.Button btnSaveAddress;
        private System.Windows.Forms.ListBox listBoxAddresses;
        private System.Windows.Forms.Label labelSavedAddresses;
    }
}

