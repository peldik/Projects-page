﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public class ChangeMealConfigurationFacade
    {
        public void ConfigureMeal(ref Meal meal, BURGERTYPE burgertype, bool FriesSalted, bool FriesPeeled, DRINKTYPE drinktype)
        {
            meal.burger.Modify(burgertype);
            meal.fries.Modify(FriesSalted, FriesPeeled);
            meal.drink.Modify(drinktype);
        }
    }
}
