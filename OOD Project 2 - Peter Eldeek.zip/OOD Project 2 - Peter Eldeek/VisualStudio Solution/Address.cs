﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public class Address
    {
        public string city { get; set; }
        public string street { get; set; }
        public string building { get; set; }
        public string residentName { get; set; }
        public int floorNumber { get; set; }

        public override string ToString()
        {
            return $"City {city}, Street {street}, Building {building}, Resident {residentName}, floor number {floorNumber}.";
        }

        public Address Clone()
        {
            return (Address)this.MemberwiseClone();
        }
    }
}
