﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public class Meal
    {
        public Burger burger = new Burger();
        public Fries fries = new Fries();
        public Drink drink = new Drink();
    }
}
