﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Order order = Order.getInstance();
        Address address = new Address();

        private void btnMakeOrder_Click(object sender, EventArgs e)
        {

            #region SaveInput
            if (rbtnBigBurger.Checked)
                order.mealBuilder = new BigMealBuilder();
            else if (rbtnMediumBurger.Checked)
                order.mealBuilder = new MediumMealBuilder();
            else if (rBtnSmallBurger.Checked)
                order.mealBuilder = new SmallMealBuilder();

            if (rbtnBeef.Checked)
                order.burgertype = BURGERTYPE.beef;
            else
                order.burgertype = BURGERTYPE.chicken;

            if (checkBoxSalted.Checked)
                order.friesSalted = true;
            else
                order.friesSalted = false;

            if (checkBoxPeeled.Checked)
                order.friesPeeled = true;
            else 
                order.friesPeeled = false;

            if (rbtnCoke.Checked)
                order.drinktype = DRINKTYPE.coke;
            else if (rbtnPepsi.Checked)
                order.drinktype = DRINKTYPE.pepsi;
            else if (rbtnMiranda.Checked)
                order.drinktype = DRINKTYPE.miranda;
            else if (rbtnSprite.Checked)
                order.drinktype = DRINKTYPE.sprite;
            else if (rbtnIceTea.Checked)
                order.drinktype = DRINKTYPE.icetea;
            #endregion

            order.ConstructMeal();

            if (listBoxAddresses.SelectedIndex >= 0)
            {
                StringBuilder confirmationstring = new StringBuilder();
                confirmationstring.Append("Order Confirmed:\n");
                confirmationstring.Append($"Burger Type: {order.burgertype} of size {order.mealBuilder.meal.burger.size}\n");
                confirmationstring.Append($"Drink Type: {order.drinktype} of size {order.mealBuilder.meal.drink.size}\n");
                confirmationstring.Append($"Fries Type: Salted: {order.friesSalted}, Peeled: {order.friesPeeled}, size: {order.mealBuilder.meal.fries.size}\n");
                confirmationstring.Append($"Address: {listBoxAddresses.SelectedItem.ToString()}");
                MessageBox.Show(confirmationstring.ToString());
            }
            else
            {
                MessageBox.Show("Please select an address first from the listbox to the right.");
            }
        }

        private void btnSaveAddress_Click(object sender, EventArgs e)
        {
            #region SaveInput
            address.city = textBoxCity.Text;
            address.street = textBoxStreet.Text;
            address.building = textBoxBuilding.Text;
            address.residentName = textBoxResidentName.Text;
            address.floorNumber = (int)numericFloorNumber.Value;
            #endregion
            listBoxAddresses.Items.Add(address.Clone());
        }
    }
}
