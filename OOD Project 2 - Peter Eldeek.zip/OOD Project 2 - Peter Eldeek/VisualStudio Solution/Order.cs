﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public class Order
    {
        private static Order instance = null;
        private Order() { }
        public static Order getInstance()
        {
            if (instance == null)
            {
                instance = new Order();
            }
            return instance;
        }

        public ChangeMealConfigurationFacade facade = new ChangeMealConfigurationFacade();
        public BURGERTYPE burgertype;
        public bool friesSalted;
        public bool friesPeeled;
        public DRINKTYPE drinktype;
        public MealBuilder mealBuilder;

        public void ConstructMeal()
        {
            mealBuilder.BuildBurger();
            mealBuilder.BuildFries();
            mealBuilder.BuildDrink();
            facade.ConfigureMeal(ref mealBuilder.meal, this.burgertype, this.friesSalted, this.friesPeeled, this.drinktype);
        }
    }
}
