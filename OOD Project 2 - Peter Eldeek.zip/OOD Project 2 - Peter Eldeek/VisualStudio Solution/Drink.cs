﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    public class Drink
    {
        public SIZE size { get; set; }
        public DRINKTYPE type { get; set; }
        public void Modify(DRINKTYPE drinktype)
        {
            this.type = drinktype;
        }
    }
}
