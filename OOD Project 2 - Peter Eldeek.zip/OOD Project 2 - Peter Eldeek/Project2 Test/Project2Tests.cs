﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Project_2;

namespace Project2_Test
{
    [TestClass]
    public class Project2Tests
    {
        [TestMethod]
        public void TestBigMealBuilder()
        {
            BigMealBuilder bigMealBuilder = new BigMealBuilder();
            bigMealBuilder.BuildBurger();
            bigMealBuilder.BuildDrink();
            bigMealBuilder.BuildFries();
            bool success = false;
            if (bigMealBuilder.meal.burger.size == SIZE.big && bigMealBuilder.meal.fries.size == SIZE.big && bigMealBuilder.meal.drink.size == SIZE.big)
                success = true;

            Assert.IsTrue(success);
        }

        [TestMethod]
        public void TestMediumMealBuilder()
        {
            MediumMealBuilder mediumMealBuilder = new MediumMealBuilder();
            mediumMealBuilder.BuildBurger();
            mediumMealBuilder.BuildDrink();
            mediumMealBuilder.BuildFries();
            bool success = false;
            if (mediumMealBuilder.meal.burger.size == SIZE.medium && mediumMealBuilder.meal.fries.size == SIZE.medium && mediumMealBuilder.meal.drink.size == SIZE.medium)
                success = true;

            Assert.IsTrue(success);
        }

        [TestMethod]
        public void TestSmallMealBuilder()
        {
            SmallMealBuilder smallMealBuilder = new SmallMealBuilder();
            smallMealBuilder.BuildBurger();
            smallMealBuilder.BuildDrink();
            smallMealBuilder.BuildFries();
            bool success = false;
            if (smallMealBuilder.meal.burger.size == SIZE.small && smallMealBuilder.meal.fries.size == SIZE.small && smallMealBuilder.meal.drink.size == SIZE.small)
                success = true;

            Assert.IsTrue(success);
        }

        [TestMethod]
        public void TestAddressClone()
        {
            Address address = new Address { city = "test1", street = "test2", building = "test3", floorNumber = 4, residentName = "test5" };
            Address clone = address.Clone();
            bool success = false;
            if (address.city == clone.city && address.street == clone.street && address.building == clone.building && address.floorNumber == clone.floorNumber && address.residentName == clone.residentName)
                success = true;

            Assert.IsTrue(success);
        }

        [TestMethod]
        public void TestBurgerModify()
        {
            Burger burger = new Burger { size = SIZE.big, type = BURGERTYPE.beef};
            burger.Modify(BURGERTYPE.chicken);

            Assert.AreEqual(burger.type, BURGERTYPE.chicken);
        }

    }
}
